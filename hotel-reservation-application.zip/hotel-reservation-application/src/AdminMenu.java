import api.AdminResource;
import model.customer.Customer;
import model.room.IRoom;
import model.room.Room;
import model.room.enums.RoomType;

import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

public class AdminMenu {

    private static final AdminResource adminResource = AdminResource.getInstance();

    public static void showMenu() {
        Scanner scanner = new Scanner(System.in);
        String choice;

        printMenu();
        try {
            do {
                choice = scanner.nextLine();
                if (choice.length() == 1) {
                    switch (choice.charAt(0)) {
                        case '1':
                            showAllCustomers();
                            break;
                        case '2':
                            showAllRooms();
                            break;
                        case '3':
                            showAllReservations();
                            break;
                        case '4':
                            addRoom();
                            break;
                        case '5':
                            MainMenu.showMainMenu();
                            break;
                        default:
                            System.out.println("Invalid option\n");
                            break;
                    }
                } else {
                    System.out.println("Error: Invalid input\n");
                }
            } while (!(choice.length() == 1 && choice.charAt(0) == '5'));
        } catch (StringIndexOutOfBoundsException e) {
            System.out.println("No input entered. Exiting...");
        }
    }

    private static void printMenu() {
        System.out.print("\nAdmin Menu\n" +
                "--------------------------------------------\n" +
                "1. View all Customers\n" +
                "2. View all Rooms\n" +
                "3. View all Reservations\n" +
                "4. Add a Room\n" +
                "5. Back to Main Menu\n" +
                "--------------------------------------------\n" +
                "Enter your choice:\n");
    }

    private static void addRoom() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter room number:");
        String roomNumber = scanner.nextLine();

        System.out.println("Enter price per night:");
        double price = readRoomPrice(scanner);

        System.out.println("Enter room type: 1 for single bed, 2 for double bed:");
        RoomType type = readRoomType(scanner);

        Room room = new Room(roomNumber, price, type);
        adminResource.addRoom(Collections.singletonList(room));

        System.out.println("Room added successfully!");
        System.out.println("Would you like to add another room? Y/N");
        askAddAnotherRoom();
    }

    private static double readRoomPrice(Scanner scanner) {
        try {
            return Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid price! Please enter a valid decimal number (use '.' for decimals).");
            return readRoomPrice(scanner);
        }
    }

    private static RoomType readRoomType(Scanner scanner) {
        try {
            return RoomType.fromCode(scanner.nextLine());
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid type! Please choose 1 for single bed or 2 for double bed:");
            return readRoomType(scanner);
        }
    }

    private static void askAddAnotherRoom() {
        Scanner scanner = new Scanner(System.in);
        try {
            String input = scanner.nextLine();

            while (input.length() != 1 || (input.charAt(0) != 'Y' && input.charAt(0) != 'N')) {
                System.out.println("Please enter Y (Yes) or N (No)");
                input = scanner.nextLine();
            }

            if (input.charAt(0) == 'Y') {
                addRoom();
            } else {
                printMenu();
            }
        } catch (StringIndexOutOfBoundsException e) {
            askAddAnotherRoom();
        }
    }

    private static void showAllRooms() {
        Collection<IRoom> rooms = adminResource.getAllRooms();
        if (rooms.isEmpty()) {
            System.out.println("No rooms found.");
        } else {
            rooms.forEach(System.out::println);
        }
    }

    private static void showAllCustomers() {
        Collection<Customer> customers = adminResource.getAllCustomers();
        if (customers.isEmpty()) {
            System.out.println("No customers found.");
        } else {
            customers.forEach(System.out::println);
        }
    }

    private static void showAllReservations() {
        adminResource.showAllReservations();
    }
}
