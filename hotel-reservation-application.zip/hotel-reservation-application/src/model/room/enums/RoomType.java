package model.room.enums;

public enum RoomType {
    SINGLE("1"),
    DOUBLE("2");

    private final String code;

    RoomType(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static RoomType fromCode(String code) {
        for (RoomType type : values()) {
            if (type.code.equals(code)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Invalid room type code: " + code);
    }
}
