package service.reservation;

import model.customer.Customer;
import model.reservation.Reservation;
import model.room.IRoom;

import java.util.*;
import java.util.stream.Collectors;

public class ReservationService {

    private static final ReservationService INSTANCE = new ReservationService();
    private static final int DEFAULT_EXTRA_DAYS = 7;

    private final Map<String, IRoom> roomMap = new HashMap<>();
    private final Map<String, Collection<Reservation>> reservationMap = new HashMap<>();

    private ReservationService() {}

    public static ReservationService getInstance() {
        return INSTANCE;
    }

    public void addRoom(IRoom room) {
        roomMap.put(room.getRoomNumber(), room);
    }

    public IRoom getRoom(String roomNumber) {
        return roomMap.get(roomNumber);
    }

    public Collection<IRoom> getAllRooms() {
        return roomMap.values();
    }

    public Reservation reserveRoom(Customer customer, IRoom room, Date checkIn, Date checkOut) {
        Reservation reservation = new Reservation(customer, room, checkIn, checkOut);
        Collection<Reservation> customerReservations = reservationMap.getOrDefault(customer.getEmail(), new LinkedList<>());
        customerReservations.add(reservation);
        reservationMap.put(customer.getEmail(), customerReservations);
        return reservation;
    }

    public Collection<IRoom> searchRooms(Date checkIn, Date checkOut) {
        return findAvailableRooms(checkIn, checkOut);
    }

    public Collection<IRoom> searchAlternativeRooms(Date checkIn, Date checkOut) {
        return findAvailableRooms(addDays(checkIn), addDays(checkOut));
    }

    private Collection<IRoom> findAvailableRooms(Date checkIn, Date checkOut) {
        Collection<IRoom> occupied = getAllReservations().stream()
                .filter(r -> overlaps(r, checkIn, checkOut))
                .map(Reservation::getRoom)
                .collect(Collectors.toList());

        return roomMap.values().stream()
                .filter(room -> !occupied.contains(room))
                .collect(Collectors.toList());
    }

    public Date addDays(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, DEFAULT_EXTRA_DAYS);
        return calendar.getTime();
    }

    private boolean overlaps(Reservation reservation, Date check
