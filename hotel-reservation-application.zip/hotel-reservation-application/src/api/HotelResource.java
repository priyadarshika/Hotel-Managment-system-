package api;

import model.customer.Customer;
import model.reservation.Reservation;
import model.room.IRoom;
import service.customer.CustomerService;
import service.reservation.ReservationService;

import java.util.Collection;
import java.util.Collections;
import java.util.Date;

public class HotelResource {

    private static final HotelResource INSTANCE = new HotelResource();

    private final CustomerService customerService = CustomerService.getSingleton();
    private final ReservationService reservationService = ReservationService.getSingleton();

    private HotelResource() {}

    public static HotelResource getInstance() {
        return INSTANCE;
    }

    public Customer fetchCustomer(String email) {
        return customerService.getCustomer(email);
    }

    public void registerCustomer(String email, String firstName, String lastName) {
        customerService.addCustomer(email, firstName, lastName);
    }

    public IRoom fetchRoom(String roomNumber) {
        return reservationService.getARoom(roomNumber);
    }

    public Reservation reserveRoom(String customerEmail, IRoom room, Date checkIn, Date checkOut) {
        return reservationService.reserveARoom(fetchCustomer(customerEmail), room, checkIn, checkOut);
    }

    public Collection<Reservation> fetchReservationsForCustomer(String customerEmail) {
        Customer customer = fetchCustomer(customerEmail);
        if (customer == null) {
            return Collections.emptyList();
        }
        return reservationService.getCustomersReservation(customer);
    }

    public Collection<IRoom> searchRooms(Date checkIn, Date checkOut) {
        return reservationService.findRooms(checkIn, checkOut);
    }

    public Collection<IRoom> searchAlternativeRooms(Date checkIn, Date checkOut) {
        return reservationService.findAlternativeRooms(checkIn, checkOut);
    }

    public Date addDaysToDefault(Date date) {
        return reservationService.addDefaultPlusDays(date);
    }
}
